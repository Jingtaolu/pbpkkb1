package d2sguide;

import java.io.*;
import java.util.*;

import chemaxon.naming.DocumentExtractor;
import chemaxon.naming.DocumentExtractor.Hit;


public class Demo1 {

    public static void main(String[] args) throws Exception {

        String test = "Aspirin:" +
        "Aspirin is the brandname of acetylsalicylic acid (ASA). It has many " +
        "uses, but is most commonly used as a pain killer, or used to reduce " +
        "fever or inflammation.";            
        
        
        //process the string and get the results
        DocumentExtractor x = new DocumentExtractor();
        x.processPlainText(new StringReader(test);
        List<Hit> hits = x.getHits();
                    
        
        //return the recognized names
        for (Hit hit : hits) {
            System.out.println(hit.text);
        }
        

        System.exit(0);

    }

}
